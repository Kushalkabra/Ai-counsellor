import React, { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { X, Send, Sparkles, CheckCircle, Star, Lock } from 'lucide-react';
import { useApp } from '@/app/context/AppContext';

export function AICounsellorPanel({ onClose }: { onClose: () => void }) {
  const { chatMessages, setChatMessages, shortlistUniversity, lockUniversity } = useApp();
  const [inputMessage, setInputMessage] = useState('');

  const handleSend = () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      type: 'user' as const,
      content: inputMessage,
      timestamp: new Date(),
    };

    // Simulate AI response
    const aiResponse = {
      id: (Date.now() + 1).toString(),
      type: 'ai' as const,
      content: generateAIResponse(inputMessage),
      timestamp: new Date(),
      actions: [
        { label: 'View Universities', universityId: undefined },
        { label: 'Update Profile', universityId: undefined },
      ],
    };

    setChatMessages([...chatMessages, userMessage, aiResponse]);
    setInputMessage('');
  };

  const generateAIResponse = (question: string) => {
    const lowerQuestion = question.toLowerCase();
    
    if (lowerQuestion.includes('university') || lowerQuestion.includes('recommend')) {
      return 'Based on your profile, I recommend focusing on universities in Canada and Germany. The University of Toronto and TU Munich are excellent matches. Would you like me to explain why these fit your goals?';
    } else if (lowerQuestion.includes('sop') || lowerQuestion.includes('statement')) {
      return 'Your Statement of Purpose should highlight your academic journey, career goals, and why you\'re choosing this specific program. I can guide you through drafting it step by step. Start by outlining your key achievements.';
    } else if (lowerQuestion.includes('exam') || lowerQuestion.includes('test')) {
      return 'For your target universities, you\'ll need IELTS (minimum 6.5) or TOEFL (minimum 90). Some programs also require GRE. I recommend taking IELTS first as it\'s accepted by all your shortlisted universities.';
    } else {
      return 'I\'m here to help with university selection, application preparation, and timeline planning. What specific aspect would you like guidance on?';
    }
  };

  const handleAction = (action: { label: string; universityId?: string }) => {
    if (action.universityId) {
      if (action.label.includes('Shortlist')) {
        shortlistUniversity(action.universityId);
      } else if (action.label.includes('Lock')) {
        lockUniversity(action.universityId);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl h-[600px] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-lg text-slate-900">Your AI Counsellor</h2>
              <p className="text-sm text-slate-500">Always here to guide you</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {chatMessages.map(message => (
            <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[80%] rounded-2xl p-4 ${
                  message.type === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-900'
                }`}
              >
                {message.type === 'ai' && (
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs text-slate-500">AI Counsellor</span>
                  </div>
                )}
                <p className="text-sm leading-relaxed">{message.content}</p>
                
                {message.actions && message.actions.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-slate-200">
                    {message.actions.map((action, idx) => (
                      <Button
                        key={idx}
                        size="sm"
                        variant="outline"
                        className="text-xs gap-1"
                        onClick={() => handleAction(action)}
                      >
                        {action.label.includes('Shortlist') && <Star className="w-3 h-3" />}
                        {action.label.includes('Lock') && <Lock className="w-3 h-3" />}
                        {action.label}
                      </Button>
                    ))}
                  </div>
                )}

                <p className="text-xs opacity-70 mt-2">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="p-6 border-t border-slate-200">
          <div className="flex gap-2">
            <Input
              placeholder="Ask about universities, applications, or next steps..."
              value={inputMessage}
              onChange={e => setInputMessage(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleSend()}
              className="flex-1"
            />
            <Button onClick={handleSend} className="bg-indigo-600 hover:bg-indigo-700 gap-2">
              <Send className="w-4 h-4" />
              Send
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
