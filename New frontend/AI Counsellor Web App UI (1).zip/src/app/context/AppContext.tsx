import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface UserProfile {
  degree: string;
  gpa: string;
  targetIntake: string;
  countries: string[];
  budgetRange: string;
  examsCompleted: string[];
  sopStatus: 'not-started' | 'draft' | 'ready';
  academicStrength: 'weak' | 'average' | 'strong';
  examStatus: 'not-started' | 'in-progress' | 'done';
}

export interface University {
  id: string;
  name: string;
  country: string;
  costLevel: 'Low' | 'Medium' | 'High';
  acceptanceChance: 'Low' | 'Medium' | 'High';
  tag: 'Dream' | 'Target' | 'Safe';
  whyFits: string;
  risks: string;
  isShortlisted: boolean;
  isLocked: boolean;
}

export interface TodoItem {
  id: string;
  text: string;
  status: 'pending' | 'in-progress' | 'done';
}

export interface ChatMessage {
  id: string;
  type: 'ai' | 'user';
  content: string;
  timestamp: Date;
  actions?: {
    label: string;
    universityId?: string;
  }[];
}

export type AppStage = 'profile-building' | 'discover-universities' | 'finalize-universities' | 'prepare-applications';

interface AppContextType {
  currentView: string;
  setCurrentView: (view: string) => void;
  onboardingCompleted: boolean;
  setOnboardingCompleted: (completed: boolean) => void;
  userProfile: UserProfile | null;
  setUserProfile: (profile: UserProfile) => void;
  currentStage: AppStage;
  setCurrentStage: (stage: AppStage) => void;
  universities: University[];
  setUniversities: (universities: University[]) => void;
  todoItems: TodoItem[];
  setTodoItems: (items: TodoItem[]) => void;
  chatMessages: ChatMessage[];
  setChatMessages: (messages: ChatMessage[]) => void;
  shortlistUniversity: (id: string) => void;
  lockUniversity: (id: string) => void;
  unlockUniversity: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentView, setCurrentView] = useState('landing');
  const [onboardingCompleted, setOnboardingCompleted] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [currentStage, setCurrentStage] = useState<AppStage>('profile-building');
  const [todoItems, setTodoItems] = useState<TodoItem[]>([
    { id: '1', text: 'Complete your academic profile', status: 'done' },
    { id: '2', text: 'Take IELTS/TOEFL exam', status: 'in-progress' },
    { id: '3', text: 'Shortlist 5-7 universities', status: 'pending' },
    { id: '4', text: 'Start drafting your SOP', status: 'pending' },
  ]);

  const [universities, setUniversities] = useState<University[]>([
    {
      id: '1',
      name: 'University of Toronto',
      country: 'Canada',
      costLevel: 'High',
      acceptanceChance: 'Medium',
      tag: 'Dream',
      whyFits: 'Strong computer science program with co-op opportunities. Your GPA and profile match their typical admitted students.',
      risks: 'High cost of living in Toronto. Competition is intense for international students.',
      isShortlisted: false,
      isLocked: false,
    },
    {
      id: '2',
      name: 'Technical University of Munich',
      country: 'Germany',
      costLevel: 'Low',
      acceptanceChance: 'High',
      tag: 'Target',
      whyFits: 'Excellent engineering programs with minimal tuition fees. Strong industry connections in Europe.',
      risks: 'Need to learn German for better job prospects. Cultural adjustment period.',
      isShortlisted: false,
      isLocked: false,
    },
    {
      id: '3',
      name: 'University of Melbourne',
      country: 'Australia',
      costLevel: 'High',
      acceptanceChance: 'High',
      tag: 'Target',
      whyFits: 'Top-ranked university with strong research focus. Good post-study work visa options.',
      risks: 'High tuition and living costs. Distance from home.',
      isShortlisted: false,
      isLocked: false,
    },
    {
      id: '4',
      name: 'University of Waterloo',
      country: 'Canada',
      costLevel: 'Medium',
      acceptanceChance: 'Medium',
      tag: 'Dream',
      whyFits: 'Best co-op program in North America. Strong tech industry placement record.',
      risks: 'Very competitive admissions. Cold climate.',
      isShortlisted: false,
      isLocked: false,
    },
    {
      id: '5',
      name: 'KTH Royal Institute of Technology',
      country: 'Sweden',
      costLevel: 'Medium',
      acceptanceChance: 'High',
      tag: 'Safe',
      whyFits: 'Strong technical programs, innovative teaching methods. English-taught programs available.',
      risks: 'Cold climate, relatively smaller job market compared to larger countries.',
      isShortlisted: false,
      isLocked: false,
    },
    {
      id: '6',
      name: 'National University of Singapore',
      country: 'Singapore',
      costLevel: 'Medium',
      acceptanceChance: 'Low',
      tag: 'Dream',
      whyFits: 'Top Asian university with global recognition. Strategic location for tech careers.',
      risks: 'Highly competitive. Limited post-study work options.',
      isShortlisted: false,
      isLocked: false,
    },
  ]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Welcome! I\'ve analyzed your profile. Based on your strong academic background in Computer Science and your budget preferences, I recommend focusing on universities in Canada, Germany, and Australia.',
      timestamp: new Date(),
      actions: [],
    },
  ]);

  const shortlistUniversity = (id: string) => {
    setUniversities(prev =>
      prev.map(uni =>
        uni.id === id ? { ...uni, isShortlisted: !uni.isShortlisted } : uni
      )
    );
  };

  const lockUniversity = (id: string) => {
    setUniversities(prev =>
      prev.map(uni =>
        uni.id === id ? { ...uni, isLocked: true, isShortlisted: true } : uni
      )
    );
  };

  const unlockUniversity = (id: string) => {
    setUniversities(prev =>
      prev.map(uni =>
        uni.id === id ? { ...uni, isLocked: false } : uni
      )
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        onboardingCompleted,
        setOnboardingCompleted,
        userProfile,
        setUserProfile,
        currentStage,
        setCurrentStage,
        universities,
        setUniversities,
        todoItems,
        setTodoItems,
        chatMessages,
        setChatMessages,
        shortlistUniversity,
        lockUniversity,
        unlockUniversity,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
