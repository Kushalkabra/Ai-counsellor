
  # AI Counsellor Web App UI

  This is a code bundle for AI Counsellor Web App UI. The original project is available at https://www.figma.com/design/kyPoo8KCDkc7EXH9hSRfpr/AI-Counsellor-Web-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  