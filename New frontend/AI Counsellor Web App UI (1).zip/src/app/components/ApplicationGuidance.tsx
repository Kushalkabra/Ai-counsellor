import React, { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Checkbox } from '@/app/components/ui/checkbox';
import {
  ArrowLeft,
  FileText,
  GraduationCap,
  FileCheck,
  Mail,
  Calendar,
  CheckCircle2,
  Circle,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '@/app/context/AppContext';

interface Document {
  id: string;
  name: string;
  completed: boolean;
  icon: React.ReactNode;
}

interface TimelineMilestone {
  month: string;
  tasks: string[];
  status: 'upcoming' | 'current' | 'completed';
}

export function ApplicationGuidance({ onBack }: { onBack: () => void }) {
  const { universities } = useApp();
  const lockedUniversities = universities.filter(u => u.isLocked);
  const [selectedUniversity, setSelectedUniversity] = useState(lockedUniversities[0]?.id || '');

  const [documents, setDocuments] = useState<Document[]>([
    {
      id: '1',
      name: 'Statement of Purpose (SOP)',
      completed: false,
      icon: <FileText className="w-5 h-5" />,
    },
    {
      id: '2',
      name: 'Academic Transcripts',
      completed: false,
      icon: <GraduationCap className="w-5 h-5" />,
    },
    {
      id: '3',
      name: 'Test Scores (IELTS/TOEFL, GRE)',
      completed: false,
      icon: <FileCheck className="w-5 h-5" />,
    },
    {
      id: '4',
      name: 'Letters of Recommendation (2-3)',
      completed: false,
      icon: <Mail className="w-5 h-5" />,
    },
    {
      id: '5',
      name: 'Resume/CV',
      completed: false,
      icon: <FileText className="w-5 h-5" />,
    },
  ]);

  const timeline: TimelineMilestone[] = [
    {
      month: 'February 2026',
      tasks: ['Finalize university list', 'Request recommendation letters', 'Start SOP draft'],
      status: 'completed',
    },
    {
      month: 'March 2026',
      tasks: ['Complete IELTS/TOEFL', 'Finalize SOP', 'Gather transcripts'],
      status: 'current',
    },
    {
      month: 'April 2026',
      tasks: ['Submit applications', 'Follow up on recommendations', 'Prepare for interviews'],
      status: 'upcoming',
    },
    {
      month: 'May 2026',
      tasks: ['Track application status', 'Prepare visa documents', 'Apply for scholarships'],
      status: 'upcoming',
    },
  ];

  const toggleDocument = (id: string) => {
    setDocuments(prev =>
      prev.map(doc => (doc.id === id ? { ...doc, completed: !doc.completed } : doc))
    );
  };

  const currentUniversity = universities.find(u => u.id === selectedUniversity);
  const completedDocs = documents.filter(d => d.completed).length;
  const totalDocs = documents.length;
  const progressPercentage = Math.round((completedDocs / totalDocs) * 100);

  if (lockedUniversities.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center max-w-md">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-2xl mb-2 text-slate-900">No Locked Universities</h2>
          <p className="text-slate-600 mb-6">
            You need to lock at least one university to access application guidance.
          </p>
          <Button onClick={onBack} className="bg-indigo-600 hover:bg-indigo-700">
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl text-slate-900">Application Guidance</h1>
              <p className="text-sm text-slate-600">
                Structured preparation for your locked universities
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* University Selector */}
        {lockedUniversities.length > 1 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6">
            <label className="text-sm text-slate-600 mb-3 block">
              Select University
            </label>
            <div className="flex flex-wrap gap-3">
              {lockedUniversities.map(uni => (
                <button
                  key={uni.id}
                  onClick={() => setSelectedUniversity(uni.id)}
                  className={`px-4 py-2 rounded-lg border-2 transition-all ${
                    selectedUniversity === uni.id
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  {uni.name}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Selected University Banner */}
        {currentUniversity && (
          <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-8 mb-6 text-white">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-3xl mb-2">{currentUniversity.name}</h2>
                <p className="text-indigo-100 mb-4">{currentUniversity.country}</p>
                <div className="flex gap-3 flex-wrap">
                  <Badge className="bg-white/20 text-white border-white/30">
                    {currentUniversity.tag}
                  </Badge>
                  <Badge className="bg-white/20 text-white border-white/30">
                    {currentUniversity.costLevel} Cost
                  </Badge>
                  <Badge className="bg-white/20 text-white border-white/30">
                    {currentUniversity.acceptanceChance} Acceptance
                  </Badge>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
                <div className="text-4xl mb-1">{progressPercentage}%</div>
                <div className="text-sm text-indigo-100">Complete</div>
              </div>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Documents Checklist */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl text-slate-900">Required Documents</h3>
                <span className="text-sm text-slate-600">
                  {completedDocs} of {totalDocs} completed
                </span>
              </div>

              <div className="space-y-4">
                {documents.map(doc => (
                  <div
                    key={doc.id}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      doc.completed
                        ? 'bg-green-50 border-green-200'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <button onClick={() => toggleDocument(doc.id)}>
                        {doc.completed ? (
                          <CheckCircle2 className="w-6 h-6 text-green-600" />
                        ) : (
                          <Circle className="w-6 h-6 text-slate-400" />
                        )}
                      </button>
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          doc.completed
                            ? 'bg-green-100 text-green-600'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {doc.icon}
                      </div>
                      <div className="flex-1">
                        <p
                          className={`${
                            doc.completed ? 'line-through text-slate-500' : 'text-slate-900'
                          }`}
                        >
                          {doc.name}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {completedDocs === totalDocs && (
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-green-900">All documents ready!</p>
                    <p className="text-sm text-green-700">You're prepared to submit your application.</p>
                  </div>
                </div>
              )}
            </div>

            {/* AI Task List Integration */}
            <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border border-purple-200 p-6">
              <h3 className="text-lg mb-3 text-slate-900">Next Steps from AI</h3>
              <div className="space-y-2">
                <div className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                  <span className="text-slate-700">Draft your SOP highlighting your research interests</span>
                </div>
                <div className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                  <span className="text-slate-700">Request recommendation from Prof. Smith by March 15</span>
                </div>
                <div className="flex items-start gap-2 text-sm">
                  <Circle className="w-4 h-4 text-slate-400 mt-0.5" />
                  <span className="text-slate-700">Schedule IELTS exam for early April</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Timeline */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sticky top-24">
              <h3 className="text-xl mb-6 text-slate-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-600" />
                Application Timeline
              </h3>

              <div className="space-y-6">
                {timeline.map((milestone, index) => (
                  <div key={milestone.month} className="relative">
                    {index < timeline.length - 1 && (
                      <div
                        className={`absolute left-3 top-8 w-0.5 h-full ${
                          milestone.status === 'completed' ? 'bg-green-600' : 'bg-slate-200'
                        }`}
                      />
                    )}
                    <div className="flex gap-3">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                          milestone.status === 'completed'
                            ? 'bg-green-600'
                            : milestone.status === 'current'
                            ? 'bg-indigo-600 ring-4 ring-indigo-100'
                            : 'bg-slate-200'
                        }`}
                      >
                        {milestone.status === 'completed' && (
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        )}
                        {milestone.status === 'current' && (
                          <Circle className="w-3 h-3 text-white fill-white" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p
                          className={`mb-2 ${
                            milestone.status === 'current'
                              ? 'text-indigo-600'
                              : 'text-slate-900'
                          }`}
                        >
                          {milestone.month}
                        </p>
                        <ul className="space-y-1">
                          {milestone.tasks.map((task, i) => (
                            <li
                              key={i}
                              className={`text-sm ${
                                milestone.status === 'completed'
                                  ? 'text-slate-500 line-through'
                                  : 'text-slate-600'
                              }`}
                            >
                              • {task}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
