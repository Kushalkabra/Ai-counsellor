import React, { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/app/components/ui/dialog';
import {
  ArrowLeft,
  MapPin,
  DollarSign,
  TrendingUp,
  ChevronDown,
  ChevronUp,
  Star,
  Lock,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';
import { useApp } from '@/app/context/AppContext';
import { motion, AnimatePresence } from 'motion/react';

interface UniversityDiscoveryProps {
  onBack: () => void;
}

export function UniversityDiscovery({ onBack }: UniversityDiscoveryProps) {
  const { universities, shortlistUniversity, lockUniversity } = useApp();
  const [expandedUniversity, setExpandedUniversity] = useState<string | null>(null);
  const [lockingUniversity, setLockingUniversity] = useState<string | null>(null);

  const handleLockClick = (id: string) => {
    setLockingUniversity(id);
  };

  const confirmLock = () => {
    if (lockingUniversity) {
      lockUniversity(lockingUniversity);
      setLockingUniversity(null);
    }
  };

  const getTagColor = (tag: string) => {
    switch (tag) {
      case 'Dream':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Target':
        return 'bg-indigo-100 text-indigo-700 border-indigo-200';
      case 'Safe':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const getCostColor = (costLevel: string) => {
    switch (costLevel) {
      case 'Low':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'Medium':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'High':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const getChanceColor = (acceptanceChance: string) => {
    switch (acceptanceChance) {
      case 'High':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'Medium':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Low':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-slate-50 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-20 left-10 w-96 h-96 bg-indigo-200/30 rounded-full blur-3xl"
          animate={{
            x: [0, 80, 0],
            y: [0, 40, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-20 right-10 w-[500px] h-[500px] bg-purple-200/30 rounded-full blur-3xl"
          animate={{
            x: [0, -60, 0],
            y: [0, 60, 0],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      {/* Header */}
      <motion.div 
        className="bg-white/70 backdrop-blur-xl border-b border-white/50 sticky top-0 z-10 shadow-sm"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </Button>
            </motion.div>
            <div className="flex-1">
              <h1 className="text-2xl text-slate-900">University Discovery</h1>
              <p className="text-sm text-slate-600">AI-matched universities based on your profile</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Universities Grid */}
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {universities.map((university, index) => (
            <motion.div
              key={university.id}
              className={`bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border transition-all ${
                university.isLocked
                  ? 'border-indigo-300 ring-2 ring-indigo-200/50'
                  : 'border-white/50'
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
            >
              <div className="p-6">
                {/* Header */}
                <div className="mb-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg text-slate-900 pr-2">{university.name}</h3>
                    {university.isLocked && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 200 }}
                      >
                        <Lock className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                      </motion.div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <MapPin className="w-4 h-4" />
                    {university.country}
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline" className={getTagColor(university.tag)}>
                    {university.tag}
                  </Badge>
                  <Badge variant="outline" className={getCostColor(university.costLevel)}>
                    <DollarSign className="w-3 h-3 mr-1" />
                    {university.costLevel}
                  </Badge>
                  <Badge variant="outline" className={getChanceColor(university.acceptanceChance)}>
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {university.acceptanceChance} Chance
                  </Badge>
                </div>

                {/* Expandable Section */}
                <div className="space-y-3">
                  <motion.button
                    onClick={() =>
                      setExpandedUniversity(expandedUniversity === university.id ? null : university.id)
                    }
                    className="w-full flex items-center justify-between p-3 bg-slate-50/50 rounded-lg hover:bg-slate-100/60 transition-colors"
                    whileHover={{ x: 3 }}
                  >
                    <span className="text-sm text-slate-900">Why this fits you</span>
                    {expandedUniversity === university.id ? (
                      <ChevronUp className="w-4 h-4 text-slate-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-500" />
                    )}
                  </motion.button>

                  <AnimatePresence>
                    {expandedUniversity === university.id && (
                      <motion.div 
                        className="space-y-3 overflow-hidden"
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <div className="p-3 bg-green-50/80 backdrop-blur-sm rounded-lg border border-green-200">
                          <div className="flex items-start gap-2">
                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <div>
                              <p className="text-xs text-green-800 mb-1">Strengths</p>
                              <p className="text-sm text-green-900">{university.whyFits}</p>
                            </div>
                          </div>
                        </div>

                        <div className="p-3 bg-amber-50/80 backdrop-blur-sm rounded-lg border border-amber-200">
                          <div className="flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                            <div>
                              <p className="text-xs text-amber-800 mb-1">Considerations</p>
                              <p className="text-sm text-amber-900">{university.risks}</p>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Actions */}
                <div className="mt-4 pt-4 border-t border-slate-200 flex gap-2">
                  {!university.isLocked ? (
                    <>
                      <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => shortlistUniversity(university.id)}
                          className={`w-full gap-1 ${
                            university.isShortlisted
                              ? 'bg-amber-100/80 border-amber-300 text-amber-700'
                              : ''
                          }`}
                        >
                          <Star
                            className={`w-4 h-4 ${university.isShortlisted ? 'fill-amber-500' : ''}`}
                          />
                          {university.isShortlisted ? 'Shortlisted' : 'Shortlist'}
                        </Button>
                      </motion.div>
                      {university.isShortlisted && (
                        <motion.div 
                          className="flex-1"
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          whileHover={{ scale: 1.02 }} 
                          whileTap={{ scale: 0.98 }}
                        >
                          <Button
                            size="sm"
                            onClick={() => handleLockClick(university.id)}
                            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 gap-1"
                          >
                            <Lock className="w-4 h-4" />
                            Lock
                          </Button>
                        </motion.div>
                      )}
                    </>
                  ) : (
                    <motion.div 
                      className="flex-1 p-2 bg-gradient-to-r from-indigo-50 to-purple-50 backdrop-blur-sm rounded-lg border border-indigo-200 text-center"
                      initial={{ scale: 0.9 }}
                      animate={{ scale: 1 }}
                    >
                      <p className="text-sm text-indigo-700">
                        🔒 Application Guidance Unlocked
                      </p>
                    </motion.div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lock Confirmation Dialog */}
      <Dialog open={!!lockingUniversity} onOpenChange={() => setLockingUniversity(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-indigo-600" />
              Lock This University?
            </DialogTitle>
            <DialogDescription className="pt-4">
              <p className="text-slate-600 leading-relaxed mb-4">
                Locking means you will start preparing applications for this university. You can unlock later, but this helps focus your effort.
              </p>
              <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                <p className="text-sm text-indigo-900">
                  ✓ Unlocks application guidance
                  <br />
                  ✓ Creates personalized timeline
                  <br />
                  ✓ Generates document checklist
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 mt-4">
            <Button
              variant="outline"
              onClick={() => setLockingUniversity(null)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button onClick={confirmLock} className="flex-1 bg-indigo-600 hover:bg-indigo-700">
              Confirm Lock
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
