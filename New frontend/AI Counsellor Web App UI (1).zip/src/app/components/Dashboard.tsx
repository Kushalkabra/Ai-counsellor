import React, { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Checkbox } from '@/app/components/ui/checkbox';
import { 
  GraduationCap, 
  MapPin, 
  DollarSign, 
  Calendar,
  CheckCircle2,
  Circle,
  Loader,
  Edit,
  MessageSquare,
  Search,
  Lock,
  FileText
} from 'lucide-react';
import { useApp } from '@/app/context/AppContext';
import { AICounsellorPanel } from './AICounsellorPanel';
import { UniversityDiscovery } from './UniversityDiscovery';
import { ApplicationGuidance } from './ApplicationGuidance';
import { motion } from 'motion/react';

const STAGES = [
  { id: 'profile-building', label: 'Profile Building' },
  { id: 'discover-universities', label: 'Discover Universities' },
  { id: 'finalize-universities', label: 'Finalize Universities' },
  { id: 'prepare-applications', label: 'Prepare Applications' },
] as const;

export function Dashboard() {
  const { userProfile, currentStage, todoItems, setTodoItems, universities, setCurrentView } = useApp();
  const [showAICounsellor, setShowAICounsellor] = useState(false);
  const [dashboardView, setDashboardView] = useState<'overview' | 'discovery' | 'applications'>('overview');

  const lockedUniversities = universities.filter(u => u.isLocked);

  const toggleTodoStatus = (id: string) => {
    setTodoItems(prev =>
      prev.map(item =>
        item.id === id
          ? {
              ...item,
              status:
                item.status === 'pending'
                  ? 'in-progress'
                  : item.status === 'in-progress'
                  ? 'done'
                  : 'pending',
            }
          : item
      )
    );
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'strong':
      case 'done':
      case 'ready':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'average':
      case 'in-progress':
      case 'draft':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'done':
        return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'in-progress':
        return <Loader className="w-4 h-4 text-amber-600" />;
      default:
        return <Circle className="w-4 h-4 text-slate-400" />;
    }
  };

  if (dashboardView === 'discovery') {
    return <UniversityDiscovery onBack={() => setDashboardView('overview')} />;
  }

  if (dashboardView === 'applications') {
    return <ApplicationGuidance onBack={() => setDashboardView('overview')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-slate-50 relative overflow-hidden">
      {/* Animated Background Blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-40 -left-20 w-96 h-96 bg-gradient-to-r from-indigo-200/40 to-purple-200/40 rounded-full blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute bottom-20 right-10 w-[500px] h-[500px] bg-gradient-to-l from-blue-200/30 to-indigo-200/30 rounded-full blur-3xl"
          animate={{
            x: [0, -80, 0],
            y: [0, 80, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      {/* Header */}
      <motion.div 
        className="bg-white/70 backdrop-blur-xl border-b border-white/50 sticky top-0 z-10 shadow-sm"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <motion.div
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <GraduationCap className="w-8 h-8 text-indigo-600" />
              </motion.div>
              <h1 className="text-2xl text-slate-900">AI Counsellor</h1>
            </div>
            <div className="flex items-center gap-3">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAICounsellor(!showAICounsellor)}
                  className="gap-2 bg-white/60 backdrop-blur-sm border-indigo-200"
                >
                  <MessageSquare className="w-4 h-4" />
                  AI Assistant
                </Button>
              </motion.div>
              <Button variant="ghost" size="sm" onClick={() => setCurrentView('landing')}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stage Progress Tracker */}
      <div className="bg-white/70 backdrop-blur-xl border-b border-white/50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center max-w-4xl mx-auto">
            {STAGES.map((stage, index) => (
              <React.Fragment key={stage.id}>
                <motion.div 
                  className="flex flex-col items-center flex-1"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <motion.div
                    className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all ${
                      currentStage === stage.id
                        ? 'bg-gradient-to-br from-indigo-600 to-purple-600 text-white ring-4 ring-indigo-200/50 shadow-lg'
                        : STAGES.findIndex(s => s.id === currentStage) > index
                        ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-md'
                        : 'bg-slate-200 text-slate-500'
                    }`}
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.2 }}
                  >
                    {STAGES.findIndex(s => s.id === currentStage) > index ? (
                      <CheckCircle2 className="w-6 h-6" />
                    ) : (
                      <span>{index + 1}</span>
                    )}
                  </motion.div>
                  <span
                    className={`text-xs md:text-sm text-center ${
                      currentStage === stage.id ? 'text-slate-900' : 'text-slate-500'
                    }`}
                  >
                    {stage.label}
                  </span>
                </motion.div>
                {index < STAGES.length - 1 && (
                  <motion.div
                    className={`flex-1 h-1 mx-2 mb-8 rounded overflow-hidden ${
                      STAGES.findIndex(s => s.id === currentStage) > index
                        ? 'bg-gradient-to-r from-green-500 to-emerald-600'
                        : 'bg-slate-200'
                    }`}
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ delay: index * 0.1 + 0.3, duration: 0.5 }}
                  />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Profile Snapshot */}
          <div className="lg:col-span-1 space-y-6">
            <motion.div 
              className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/50 p-6"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-lg text-slate-900">Profile Snapshot</h2>
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                  <Button variant="ghost" size="sm" className="gap-1">
                    <Edit className="w-4 h-4" />
                    Edit
                  </Button>
                </motion.div>
              </div>

              {userProfile && (
                <div className="space-y-4">
                  <motion.div 
                    className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-indigo-50/50 to-transparent"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <GraduationCap className="w-5 h-5 text-indigo-500 mt-0.5" />
                    <div>
                      <p className="text-sm text-slate-500">Degree & GPA</p>
                      <p className="text-slate-900">{userProfile.degree}</p>
                      <p className="text-slate-900">{userProfile.gpa}</p>
                    </div>
                  </motion.div>

                  <motion.div 
                    className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-purple-50/50 to-transparent"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Calendar className="w-5 h-5 text-purple-500 mt-0.5" />
                    <div>
                      <p className="text-sm text-slate-500">Target Intake</p>
                      <p className="text-slate-900">{userProfile.targetIntake}</p>
                    </div>
                  </motion.div>

                  <motion.div 
                    className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-blue-50/50 to-transparent"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <MapPin className="w-5 h-5 text-blue-500 mt-0.5" />
                    <div>
                      <p className="text-sm text-slate-500">Countries</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {userProfile.countries.map(country => (
                          <Badge key={country} variant="secondary" className="text-xs bg-white/60">
                            {country}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </motion.div>

                  <motion.div 
                    className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-green-50/50 to-transparent"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <DollarSign className="w-5 h-5 text-green-500 mt-0.5" />
                    <div>
                      <p className="text-sm text-slate-500">Budget Range</p>
                      <p className="text-slate-900 capitalize">{userProfile.budgetRange}</p>
                    </div>
                  </motion.div>
                </div>
              )}
            </motion.div>

            {/* Profile Strength Card */}
            <motion.div 
              className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/50 p-6"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h2 className="text-lg mb-4 text-slate-900">Profile Strength</h2>

              {userProfile && (
                <div className="space-y-3">
                  <motion.div 
                    className="flex justify-between items-center p-3 rounded-lg bg-slate-50/50"
                    whileHover={{ scale: 1.02 }}
                  >
                    <span className="text-sm text-slate-600">Academics</span>
                    <Badge
                      variant="outline"
                      className={`capitalize ${getStrengthColor(userProfile.academicStrength)}`}
                    >
                      {userProfile.academicStrength}
                    </Badge>
                  </motion.div>

                  <motion.div 
                    className="flex justify-between items-center p-3 rounded-lg bg-slate-50/50"
                    whileHover={{ scale: 1.02 }}
                  >
                    <span className="text-sm text-slate-600">Exams</span>
                    <Badge
                      variant="outline"
                      className={`capitalize ${getStrengthColor(userProfile.examStatus)}`}
                    >
                      {userProfile.examStatus.replace('-', ' ')}
                    </Badge>
                  </motion.div>

                  <motion.div 
                    className="flex justify-between items-center p-3 rounded-lg bg-slate-50/50"
                    whileHover={{ scale: 1.02 }}
                  >
                    <span className="text-sm text-slate-600">SOP</span>
                    <Badge
                      variant="outline"
                      className={`capitalize ${getStrengthColor(userProfile.sopStatus)}`}
                    >
                      {userProfile.sopStatus.replace('-', ' ')}
                    </Badge>
                  </motion.div>
                </div>
              )}
            </motion.div>
          </div>

          {/* Right Column - Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <div className="grid md:grid-cols-3 gap-4">
              <motion.button
                onClick={() => setDashboardView('discovery')}
                className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white rounded-2xl p-6 text-left shadow-xl hover:shadow-2xl transition-all relative overflow-hidden group"
                whileHover={{ y: -4, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/0 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                <Search className="w-8 h-8 mb-3 opacity-90 relative z-10" />
                <h3 className="text-lg mb-1 relative z-10">Discover Universities</h3>
                <p className="text-sm opacity-90 relative z-10">Browse AI-matched options</p>
              </motion.button>

              <motion.button
                onClick={() => lockedUniversities.length > 0 && setDashboardView('applications')}
                className={`bg-gradient-to-br rounded-2xl p-6 text-left shadow-xl hover:shadow-2xl transition-all relative overflow-hidden group ${
                  lockedUniversities.length > 0
                    ? 'from-green-500 to-green-600 text-white'
                    : 'from-slate-200 to-slate-300 text-slate-500 cursor-not-allowed'
                }`}
                whileHover={lockedUniversities.length > 0 ? { y: -4, scale: 1.02 } : {}}
                whileTap={lockedUniversities.length > 0 ? { scale: 0.98 } : {}}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/0 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                <FileText className="w-8 h-8 mb-3 opacity-90 relative z-10" />
                <h3 className="text-lg mb-1 relative z-10">Application Guide</h3>
                <p className="text-sm opacity-90 relative z-10">
                  {lockedUniversities.length > 0
                    ? `${lockedUniversities.length} locked`
                    : 'Lock universities first'}
                </p>
              </motion.button>

              <motion.button 
                className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-2xl p-6 text-left shadow-xl hover:shadow-2xl transition-all relative overflow-hidden group"
                whileHover={{ y: -4, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/0 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                <Lock className="w-8 h-8 mb-3 opacity-90 relative z-10" />
                <h3 className="text-lg mb-1 relative z-10">Shortlisted</h3>
                <p className="text-sm opacity-90 relative z-10">
                  {universities.filter(u => u.isShortlisted).length} universities
                </p>
              </motion.button>
            </div>

            {/* AI To-Do List */}
            <motion.div 
              className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/50 p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg text-slate-900">Your Action Items</h2>
                <Badge variant="secondary" className="gap-1 bg-indigo-100/60 text-indigo-700">
                  <MessageSquare className="w-3 h-3" />
                  AI generated
                </Badge>
              </div>

              <div className="space-y-3">
                {todoItems.map((item, index) => (
                  <motion.div
                    key={item.id}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-white/60 transition-colors backdrop-blur-sm"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    whileHover={{ x: 5 }}
                  >
                    <motion.button 
                      onClick={() => toggleTodoStatus(item.id)} 
                      className="mt-0.5"
                      whileHover={{ scale: 1.2 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      {getStatusIcon(item.status)}
                    </motion.button>
                    <div className="flex-1">
                      <p
                        className={`text-sm ${
                          item.status === 'done'
                            ? 'line-through text-slate-400'
                            : 'text-slate-900'
                        }`}
                      >
                        {item.text}
                      </p>
                      <Badge
                        variant="outline"
                        className={`mt-1 text-xs ${getStrengthColor(item.status)}`}
                      >
                        {item.status.replace('-', ' ')}
                      </Badge>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Locked Universities Preview */}
            {lockedUniversities.length > 0 && (
              <motion.div 
                className="bg-gradient-to-br from-indigo-100/60 to-purple-100/40 backdrop-blur-xl rounded-2xl border border-indigo-200/50 p-6 shadow-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 }}
              >
                <h2 className="text-lg mb-4 text-slate-900 flex items-center gap-2">
                  <Lock className="w-5 h-5 text-indigo-600" />
                  Locked Universities
                </h2>
                <div className="space-y-2">
                  {lockedUniversities.map((uni, index) => (
                    <motion.div
                      key={uni.id}
                      className="bg-white/80 backdrop-blur-sm rounded-lg p-3 flex items-center justify-between"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 1 + index * 0.1 }}
                      whileHover={{ x: 5, backgroundColor: "rgba(255,255,255,0.95)" }}
                    >
                      <div>
                        <p className="text-slate-900">{uni.name}</p>
                        <p className="text-sm text-slate-500">{uni.country}</p>
                      </div>
                      <Badge className="bg-indigo-600">Locked</Badge>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* AI Counsellor Panel */}
      {showAICounsellor && <AICounsellorPanel onClose={() => setShowAICounsellor(false)} />}
    </div>
  );
}
